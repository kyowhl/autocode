package com.sanqing.api.help.shsxzd;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.page.SplitPage;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 查询属性字典
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class QuerySHSXZD extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
				
		Map<String,String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		//数据合法性校验
		String qSXZDBH = requestMap.get("qSXZDBH");
		CheckText.checkFormat(qSXZDBH,"N",22,0,1,"属性字典编号（SXZDBH）");
		String qZDBH = requestMap.get("qZDBH");
		CheckText.checkFormat(qZDBH,"N",22,0,0,"字典编号");
		String qZDV = requestMap.get("qZDV");
		CheckText.checkFormat(qZDV,"C",64,0,0,"字典value");
		String qZDK = requestMap.get("qZDK");
		CheckText.checkFormat(qZDK,"C",128,0,0,"字典key");
		String whereStr = "";
		String orderbyStr = "  order by t.SXZDBH desc";
		List<Object> searchParameterList = new ArrayList<Object>();
		if(qSXZDBH != null && !"".equals(qSXZDBH)){
			whereStr = whereStr + " and t.SXZDBH = ? ";
			searchParameterList.add(qSXZDBH);
		}
		if(qZDBH != null && !"".equals(qZDBH)){
			whereStr = whereStr + " and t.ZDBH = ? ";
			searchParameterList.add(qZDBH);
		}
		if(qZDV != null && !"".equals(qZDV)){
			whereStr = whereStr + " and t.ZDV = ? ";
			searchParameterList.add(qZDV);
		}
		if(qZDK != null && !"".equals(qZDK)){
			whereStr = whereStr + " and t.ZDK = ? ";
			searchParameterList.add(qZDK);
		}
		String sql = "select * from SH_SXZD t where 1=1 "+ whereStr + orderbyStr;
		SplitPage sp = dao.splitPage(SplitPage.getInstance(protocol.getData(PageConfig.PAGE_SPLIT)), sql, searchParameterList);
		sp.buildProtocol(protocol);
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}