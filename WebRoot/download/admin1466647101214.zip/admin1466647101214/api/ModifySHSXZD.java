package com.sanqing.api.help.shsxzd;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;

/**
 * 修改属性字典
 * 
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class ModifySHSXZD extends BaseAgent {

	@Override
	public Protocol execute(Protocol protocol) throws Exception {

		Map<String, String> requestMap = protocol
				.getData(PageConfig.PAGE_REQUEST);
		String SXZDBH = requestMap.get("SXZDBH");
		CheckText.checkFormat(SXZDBH,"N",22,0,1,"属性字典编号（SXZDBH）");
		String ZDBH = requestMap.get("ZDBH");
		CheckText.checkFormat(ZDBH,"N",22,0,0,"字典编号");
		String ZDV = requestMap.get("ZDV");
		CheckText.checkFormat(ZDV,"C",64,0,0,"字典value");
		String ZDK = requestMap.get("ZDK");
		CheckText.checkFormat(ZDK,"C",128,0,0,"字典key");
		// 根据主键修改对象
		Map<String, Object> map = new HashMap<String, Object>();
		Map<String, Object> conditionMap = new HashMap<String, Object>();
		// 构建更新对象map
		// 构建更新表条件conditionMap
		conditionMap.put("SXZDBH", SXZDBH);
		map.put("ZDBH", ZDBH);
		map.put("ZDV", ZDV);
		map.put("ZDK", ZDK);
		// 更新表
		dao.update("SH_SXZD", map, conditionMap);
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);

		return protocol;
	}
}