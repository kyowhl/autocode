package com.sanqing.api.help.shsxzd;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 添加属性字典
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class AddSHSXZD extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
    	Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		String ZDBH = requestMap.get("ZDBH");
		CheckText.checkFormat(ZDBH,"N",22,0,0,"字典编号");
		String ZDV = requestMap.get("ZDV");
		CheckText.checkFormat(ZDV,"C",64,0,0,"字典value");
		String ZDK = requestMap.get("ZDK");
		CheckText.checkFormat(ZDK,"C",128,0,0,"字典key");
		//添加属性字典到数据库
		Map<String, Object> map = new HashMap<String, Object>();
		long SXZDBH = dao.getNextval("SEQ_GG_PUBLIC");
		map.put("SXZDBH", SXZDBH);
		map.put("ZDBH", ZDBH);
		map.put("ZDV", ZDV);
		map.put("ZDK", ZDK);
		dao.add("SH_SXZD", map);
		
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}
