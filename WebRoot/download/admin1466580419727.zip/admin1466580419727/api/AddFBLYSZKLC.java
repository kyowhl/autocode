package fblyszklc;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 添加应收账款表(F_BL_YSZK_LC
 * @author admin
 * @time 2016-06-22
 * @version 1.0
 */
public class AddFBLYSZKLC extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
    	Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		String YWBH = requestMap.get("YWBH");
		CheckText.checkFormat(YWBH,"N",22,0,0,"业务编号");
		String QDBH = requestMap.get("QDBH");
		CheckText.checkFormat(QDBH,"N",22,0,0,"渠道编号");
		String KHBH = requestMap.get("KHBH");
		CheckText.checkFormat(KHBH,"C",19,0,1,"客户编号");
		String KHMC = requestMap.get("KHMC");
		CheckText.checkFormat(KHMC,"C",256,0,1,"客户名称");
		String LRSJ = requestMap.get("LRSJ");
		CheckText.checkFormat(LRSJ,"D",7,0,0,"录入时间");
		String GSJG = requestMap.get("GSJG");
		CheckText.checkFormat(GSJG,"C",15,0,0,"归属机构");
		String DDBH = requestMap.get("DDBH");
		CheckText.checkFormat(DDBH,"N",22,0,0,"订单编号");
		String CPBH = requestMap.get("CPBH");
		CheckText.checkFormat(CPBH,"N",22,0,0,"产品编号");
		String JYGXLSH = requestMap.get("JYGXLSH");
		CheckText.checkFormat(JYGXLSH,"N",22,0,0,"渠道交易关系流水号");
		String BB = requestMap.get("BB");
		CheckText.checkFormat(BB,"C",3,0,0,"币别");
		String FPHM = requestMap.get("FPHM");
		CheckText.checkFormat(FPHM,"C",20,0,1,"发票号码");
		String YSZKJE = requestMap.get("YSZKJE");
		CheckText.checkFormat(YSZKJE,"N",16,4,0,"应收账款金额");
		String FPPMJE = requestMap.get("FPPMJE");
		CheckText.checkFormat(FPPMJE,"N",16,4,0,"发票票面金额");
		String FPR = requestMap.get("FPR");
		CheckText.checkFormat(FPR,"C",10,0,0,"发票日");
		String FKR = requestMap.get("FKR");
		CheckText.checkFormat(FKR,"C",10,0,0,"付款日");
		String FJ = requestMap.get("FJ");
		CheckText.checkFormat(FJ,"C",256,0,0,"附件");
		String BZ = requestMap.get("BZ");
		CheckText.checkFormat(BZ,"C",4000,0,0,"备注");
		String QDFPLSH = requestMap.get("QDFPLSH");
		CheckText.checkFormat(QDFPLSH,"N",22,0,0,"渠道发票流水号");
		String BLHTBH = requestMap.get("BLHTBH");
		CheckText.checkFormat(BLHTBH,"C",30,0,0,"保理合同编号");
		String YSZKYE = requestMap.get("YSZKYE");
		CheckText.checkFormat(YSZKYE,"N",16,4,0,"应收账款余额");
		String FPZT = requestMap.get("FPZT");
		CheckText.checkFormat(FPZT,"C",1,0,0,"0-未提交1.已提交2，已确认3.已拒绝4.已录入");
		String QDJJYY = requestMap.get("QDJJYY");
		CheckText.checkFormat(QDJJYY,"C",400,0,0,"渠道拒绝原因");
		String YSZKQRZT = requestMap.get("YSZKQRZT");
		CheckText.checkFormat(YSZKQRZT,"C",1,0,0,"0-未确认1.已提交2.已确认3.拒绝");
		String MFQDKHBH = requestMap.get("MFQDKHBH");
		CheckText.checkFormat(MFQDKHBH,"C",20,0,0,"买方渠道客户编号");
		String MFKHBH = requestMap.get("MFKHBH");
		CheckText.checkFormat(MFKHBH,"C",19,0,0,"买方客户编号");
		String MFKHMC = requestMap.get("MFKHMC");
		CheckText.checkFormat(MFKHMC,"C",256,0,0,"买方客户名称");
		String MFQRSJ = requestMap.get("MFQRSJ");
		CheckText.checkFormat(MFQRSJ,"D",7,0,0,"买方确认时间");
		String MFQRZT = requestMap.get("MFQRZT");
		CheckText.checkFormat(MFQRZT,"C",1,0,0,"0-未确认1。已确认2。拒绝");
		String JJYY = requestMap.get("JJYY");
		CheckText.checkFormat(JJYY,"C",400,0,0,"拒绝原因");
		String MFFJ = requestMap.get("MFFJ");
		CheckText.checkFormat(MFFJ,"C",200,0,0,"买方附件");
		//添加应收账款表(F_BL_YSZK_LC到数据库
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("YWBH", YWBH);
		long YSZKBH = dao.getNextval("SEQ_GG_PUBLIC");
		map.put("YSZKBH", YSZKBH);
		map.put("QDBH", QDBH);
		map.put("KHBH", KHBH);
		map.put("KHMC", KHMC);
		map.put("LRSJ", LRSJ);
		map.put("GSJG", GSJG);
		map.put("DDBH", DDBH);
		map.put("CPBH", CPBH);
		map.put("JYGXLSH", JYGXLSH);
		map.put("BB", BB);
		map.put("FPHM", FPHM);
		map.put("YSZKJE", YSZKJE);
		map.put("FPPMJE", FPPMJE);
		map.put("FPR", FPR);
		map.put("FKR", FKR);
		map.put("FJ", FJ);
		map.put("BZ", BZ);
		map.put("QDFPLSH", QDFPLSH);
		map.put("BLHTBH", BLHTBH);
		map.put("YSZKYE", YSZKYE);
		map.put("FPZT", FPZT);
		map.put("QDJJYY", QDJJYY);
		map.put("YSZKQRZT", YSZKQRZT);
		map.put("MFQDKHBH", MFQDKHBH);
		map.put("MFKHBH", MFKHBH);
		map.put("MFKHMC", MFKHMC);
		map.put("MFQRSJ", MFQRSJ);
		map.put("MFQRZT", MFQRZT);
		map.put("JJYY", JJYY);
		map.put("MFFJ", MFFJ);
		dao.add("F_BL_YSZK_LC", map);
		
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}
