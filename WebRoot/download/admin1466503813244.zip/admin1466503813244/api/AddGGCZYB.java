package com.sanqing.api.help.xtbz;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 添加系统帮助
 * @author wanghl
 * @time 2016年6月06日
 * @version 1.0
 */
public class AddXTBZ extends BaseAgent{
	
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
		
		Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		String zybh = requestMap.get("zybh");
		String gnbh = requestMap.get("gnbh");
		String bzsm = requestMap.get("bzsm");
		CheckText.checkFormat(zybh, "C", 30, 0, 1, "资源编号");
		CheckText.checkFormat(gnbh, "C", 15, 0, 1, "功能编号");
		CheckText.checkFormat(bzsm, "C", 0, 0, 1, "帮助说明");
		
		long bzbh = dao.getNextval("SEQ_GG_PUBLIC");
		//添加对象
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("BZBH", bzbh);
		map.put("ZYBH", zybh);
		map.put("GNBH", gnbh);
		map.put("BZSM", bzsm);
		dao.add("H_SYBZB", map);
		
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}
