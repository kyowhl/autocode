package fblhtzh;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 添加保理合同账户
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class AddFBLHTZH extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
    	Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		String BLHTBH = requestMap.get("BLHTBH");
		CheckText.checkFormat(BLHTBH,"C",64,0,1,"保理合同编号");
		String QDBH = requestMap.get("QDBH");
		CheckText.checkFormat(QDBH,"N",22,0,0,"渠道编号");
		String QDKHH = requestMap.get("QDKHH");
		CheckText.checkFormat(QDKHH,"C",20,0,1,"渠道客户号");
		String ZHZL = requestMap.get("ZHZL");
		CheckText.checkFormat(ZHZL,"C",120,0,0,"账户种类");
		String MFMC = requestMap.get("MFMC");
		CheckText.checkFormat(MFMC,"C",120,0,0,"买方名称");
		String BZ = requestMap.get("BZ");
		CheckText.checkFormat(BZ,"C",3,0,0,"币种");
		String KHH = requestMap.get("KHH");
		CheckText.checkFormat(KHH,"C",120,0,0,"开户行");
		String ZH = requestMap.get("ZH");
		CheckText.checkFormat(ZH,"C",30,0,0,"账号");
		String KHM = requestMap.get("KHM");
		CheckText.checkFormat(KHM,"C",120,0,0,"开户名");
		String MFKHBH = requestMap.get("MFKHBH");
		CheckText.checkFormat(MFKHBH,"C",20,0,0,"买方客户编号");
		String MFQDKHH = requestMap.get("MFQDKHH");
		CheckText.checkFormat(MFQDKHH,"C",20,0,0,"买方渠道客户号");
		//添加保理合同账户到数据库
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("BLHTBH", BLHTBH);
		map.put("QDBH", QDBH);
		map.put("QDKHH", QDKHH);
		map.put("ZHZL", ZHZL);
		map.put("MFMC", MFMC);
		map.put("BZ", BZ);
		map.put("KHH", KHH);
		map.put("ZH", ZH);
		map.put("KHM", KHM);
		map.put("MFKHBH", MFKHBH);
		map.put("MFQDKHH", MFQDKHH);
		dao.add("F_BLHTZH", map);
		
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}
