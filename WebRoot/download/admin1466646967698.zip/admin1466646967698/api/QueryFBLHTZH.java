package fblhtzh;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.page.SplitPage;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 查询保理合同账户
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class QueryFBLHTZH extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
				
		Map<String,String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		//数据合法性校验
		String qBLHTBH = requestMap.get("qBLHTBH");
		CheckText.checkFormat(qBLHTBH,"C",64,0,1,"保理合同编号");
		String qQDBH = requestMap.get("qQDBH");
		CheckText.checkFormat(qQDBH,"N",22,0,0,"渠道编号");
		String qQDKHH = requestMap.get("qQDKHH");
		CheckText.checkFormat(qQDKHH,"C",20,0,1,"渠道客户号");
		String qZHZL = requestMap.get("qZHZL");
		CheckText.checkFormat(qZHZL,"C",120,0,0,"账户种类");
		String qMFMC = requestMap.get("qMFMC");
		CheckText.checkFormat(qMFMC,"C",120,0,0,"买方名称");
		String qBZ = requestMap.get("qBZ");
		CheckText.checkFormat(qBZ,"C",3,0,0,"币种");
		String qKHH = requestMap.get("qKHH");
		CheckText.checkFormat(qKHH,"C",120,0,0,"开户行");
		String qZH = requestMap.get("qZH");
		CheckText.checkFormat(qZH,"C",30,0,0,"账号");
		String qKHM = requestMap.get("qKHM");
		CheckText.checkFormat(qKHM,"C",120,0,0,"开户名");
		String qMFKHBH = requestMap.get("qMFKHBH");
		CheckText.checkFormat(qMFKHBH,"C",20,0,0,"买方客户编号");
		String qMFQDKHH = requestMap.get("qMFQDKHH");
		CheckText.checkFormat(qMFQDKHH,"C",20,0,0,"买方渠道客户号");
		String whereStr = "";
		String orderbyStr = "  order by t.${pkColumn.columnName} desc";
		List<Object> searchParameterList = new ArrayList<Object>();
		if(qBLHTBH != null && !"".equals(qBLHTBH)){
			whereStr = whereStr + " and t.BLHTBH = ? ";
			searchParameterList.add(qBLHTBH);
		}
		if(qQDBH != null && !"".equals(qQDBH)){
			whereStr = whereStr + " and t.QDBH = ? ";
			searchParameterList.add(qQDBH);
		}
		if(qQDKHH != null && !"".equals(qQDKHH)){
			whereStr = whereStr + " and t.QDKHH = ? ";
			searchParameterList.add(qQDKHH);
		}
		if(qZHZL != null && !"".equals(qZHZL)){
			whereStr = whereStr + " and t.ZHZL = ? ";
			searchParameterList.add(qZHZL);
		}
		if(qMFMC != null && !"".equals(qMFMC)){
			whereStr = whereStr + " and t.MFMC = ? ";
			searchParameterList.add(qMFMC);
		}
		if(qBZ != null && !"".equals(qBZ)){
			whereStr = whereStr + " and t.BZ = ? ";
			searchParameterList.add(qBZ);
		}
		if(qKHH != null && !"".equals(qKHH)){
			whereStr = whereStr + " and t.KHH = ? ";
			searchParameterList.add(qKHH);
		}
		if(qZH != null && !"".equals(qZH)){
			whereStr = whereStr + " and t.ZH = ? ";
			searchParameterList.add(qZH);
		}
		if(qKHM != null && !"".equals(qKHM)){
			whereStr = whereStr + " and t.KHM = ? ";
			searchParameterList.add(qKHM);
		}
		if(qMFKHBH != null && !"".equals(qMFKHBH)){
			whereStr = whereStr + " and t.MFKHBH = ? ";
			searchParameterList.add(qMFKHBH);
		}
		if(qMFQDKHH != null && !"".equals(qMFQDKHH)){
			whereStr = whereStr + " and t.MFQDKHH = ? ";
			searchParameterList.add(qMFQDKHH);
		}
		String sql = "select * from F_BLHTZH t where 1=1 "+ whereStr + orderbyStr;
		SplitPage sp = dao.splitPage(SplitPage.getInstance(protocol.getData(PageConfig.PAGE_SPLIT)), sql, searchParameterList);
		sp.buildProtocol(protocol);
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}