package fblhtzh;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.sanqing.exception.MyException;
import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 查看保理合同账户
 * @author admin
 * @time 2016-06-23
 * @version 1.0
 */
public class ViewFBLHTZH extends BaseAgent {
	@Override
	public Protocol execute(Protocol protocol) throws Exception {

		Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		// 数据合法性校验
		String ${pkColumn.columnName} = requestMap.get("${pkColumn.columnName}");
		CheckText.checkFormat(${pkColumn.columnName},"${pkColumn.checkType}",${pkColumn.length},${pkColumn.scale},${pkColumn.isNull},"${pkColumn.comment}");

		// 查询指定对象返回
		String sql = "select * from F_BLHTZH t where t.${pkColumn.columnName} = ?";
		Map<String, Object> map = dao.queryForMap(sql, ${pkColumn.columnName});

		if (map == null || map.isEmpty()) {
			throw new MyException(ReturnCode.TASK_EXCEPTION_CODE, "没有找到相应的数据！");
		}

		List<Map<String, Object>> reList = new ArrayList<Map<String, Object>>();
		reList.add(map);
		protocol.putTable("getObj", reList);

		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);

		return protocol;
	}
}