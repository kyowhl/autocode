package com.sanqing.api.help.autotest;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.page.SplitPage;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 查询代码工具测试
 * @author admin
 * @time 2016-07-04
 * @version 1.0
 */
public class QueryAUTOTEST extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
				
		Map<String,String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		//数据合法性校验
		String qID = requestMap.get("qID");
		CheckText.checkFormat(qID,"N",22,0,2,"ID");
		String qCODE = requestMap.get("qCODE");
		CheckText.checkFormat(qCODE,"C",20,0,2,"代码");
		String qNAME = requestMap.get("qNAME");
		CheckText.checkFormat(qNAME,"C",100,0,2,"名称");
		String qZP_FJ = requestMap.get("qZP_FJ");
		CheckText.checkFormat(qZP_FJ,"C",3000,0,2,"照片附件");
		String qQTZT = requestMap.get("qQTZT");
		CheckText.checkFormat(qQTZT,"C",1,0,2,"启停状态");
		String whereStr = "";
		String orderbyStr = "  order by t.ID desc";
		List<Object> searchParameterList = new ArrayList<Object>();
		if(qID != null && !"".equals(qID)){
			whereStr = whereStr + " and t.ID = ? ";
			searchParameterList.add(qID);
		}
		if(qCODE != null && !"".equals(qCODE)){
			whereStr = whereStr + " and t.CODE = ? ";
			searchParameterList.add(qCODE);
		}
		if(qNAME != null && !"".equals(qNAME)){
			whereStr = whereStr + " and t.NAME = ? ";
			searchParameterList.add(qNAME);
		}
		if(qZP_FJ != null && !"".equals(qZP_FJ)){
			whereStr = whereStr + " and t.ZP_FJ = ? ";
			searchParameterList.add(qZP_FJ);
		}
		if(qQTZT != null && !"".equals(qQTZT)){
			whereStr = whereStr + " and t.QTZT = ? ";
			searchParameterList.add(qQTZT);
		}
		String sql = "select * from AUTO_TEST t where 1=1 "+ whereStr + orderbyStr;
		SplitPage sp = dao.splitPage(SplitPage.getInstance(protocol.getData(PageConfig.PAGE_SPLIT)), sql, searchParameterList);
		sp.buildProtocol(protocol);
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}