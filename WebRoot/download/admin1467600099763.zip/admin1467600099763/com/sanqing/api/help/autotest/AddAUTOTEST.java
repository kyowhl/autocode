package com.sanqing.api.help.autotest;

import java.util.HashMap;
import java.util.Map;

import com.sanqing.page.CheckText;
import com.sanqing.page.PageConfig;
import com.sanqing.sca.service.BaseAgent;
import com.sanqing.sca.service.Protocol;
import com.sanqing.sca.service.ReturnCode;
/**
 * 添加代码工具测试
 * @author admin
 * @time 2016-07-04
 * @version 1.0
 */
public class AddAUTOTEST extends BaseAgent{
	@Override
	public Protocol execute(Protocol protocol) throws Exception{
    	Map<String, String> requestMap = protocol.getData(PageConfig.PAGE_REQUEST);
		String CODE = requestMap.get("CODE");
		CheckText.checkFormat(CODE,"C",20,0,2,"代码");
		String NAME = requestMap.get("NAME");
		CheckText.checkFormat(NAME,"C",100,0,2,"名称");
		String ZP_FJ = requestMap.get("ZP_FJ");
		CheckText.checkFormat(ZP_FJ,"C",3000,0,2,"照片附件");
		String QTZT = requestMap.get("QTZT");
		CheckText.checkFormat(QTZT,"C",1,0,2,"启停状态");
		//添加代码工具测试到数据库
		Map<String, Object> map = new HashMap<String, Object>();
		long ID = dao.getNextval("SEQ_GG_PUBLIC");
		map.put("ID", ID);
		map.put("CODE", CODE);
		map.put("NAME", NAME);
		map.put("ZP_FJ", ZP_FJ);
		map.put("QTZT", QTZT);
		dao.add("AUTO_TEST", map);
		
		protocol.setRecode(ReturnCode.SUCCESS_CODE);
		protocol.setRemsg(ReturnCode.SUCCESS_REMSG);
		return protocol;
	}
}
